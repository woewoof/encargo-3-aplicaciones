package com.pasteleria.backend;

import com.pasteleria.backend.model.Producto;
import com.pasteleria.backend.repository.ProductoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(ProductoRepository repository) {
        return args -> {
            repository.save(new Producto("Torta Chocolate", 45000.0, 0, "Tortas", 10));
            repository.save(new Producto("Torta Vainilla", 40000.0, 0, "Tortas", 5));
            repository.save(new Producto("Torta Naranja", 42000.0, 0, "Sin Azúcar", 7));
            System.out.println("✅ Datos de prueba cargados en Spring Boot");
        };
    }
}