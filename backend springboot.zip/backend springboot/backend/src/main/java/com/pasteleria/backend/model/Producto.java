package com.pasteleria.backend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private Double precio;
    private Integer imagen;
    private String categoria;
    private Integer stock;


    public Producto() {}

    public Producto(String nombre, Double precio, Integer imagen, String categoria, Integer stock) {
        this.nombre = nombre;
        this.precio = precio;
        this.imagen = imagen;
        this.categoria = categoria;
        this.stock = stock;
    }

    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public Double getPrecio() { return precio; }
    public Integer getImagen() { return imagen; }
    public String getCategoria() { return categoria; }
    public Integer getStock() { return stock; }
}