package com.pasteleria.backend.controller;

import com.pasteleria.backend.model.Cliente;
import com.pasteleria.backend.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @PostMapping("/clientes")
    public Cliente guardarCliente(@RequestBody Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    @GetMapping("/clientes/{correo}")
    public Cliente buscarCliente(@PathVariable String correo) {
        Optional<Cliente> cliente = clienteRepository.findByCorreo(correo);
        return cliente.orElse(null);
    }

    @DeleteMapping("/clientes/{correo}")
    public void eliminarCliente(@PathVariable String correo) {
        clienteRepository.deleteByCorreo(correo);
    }
}
