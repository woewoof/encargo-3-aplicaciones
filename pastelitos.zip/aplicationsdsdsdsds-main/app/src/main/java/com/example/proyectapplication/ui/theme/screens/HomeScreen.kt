package com.example.proyectapplication.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.proyectapplication.R
import com.example.proyectapplication.models.Producto
import com.example.proyectapplication.ui.theme.screens.MintGreen
import com.example.proyectapplication.ui.theme.screens.PastelPink
import com.example.proyectapplication.ui.theme.screens.CreamWhite
import com.example.proyectapplication.ui.theme.screens.ChocolateBrown
import com.example.proyectapplication.ui.theme.screens.AccentYellow
import com.example.proyectapplication.ui.theme.screens.ErrorRed
import com.example.proyectapplication.ui.viewmodel.MainViewModel
import com.example.proyectapplication.ui.viewmodel.UiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class PantallaActual {
    Catalogo,
    Carrito,
    Venta
}

@Composable
fun HomeScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    // Ahora arranca directo en el Catálogo
    var pantalla by remember { mutableStateOf(PantallaActual.Catalogo) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun mostrarMensaje(texto: String) {
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(
                message = texto,
                duration = SnackbarDuration.Short
            )
        }
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Surface(
                    color = ChocolateBrown,
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = MintGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = data.visuals.message,
                            color = CreamWhite,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        containerColor = Color.Transparent
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (pantalla) {
                // Ya no existe el caso Bienvenida aquí
                PantallaActual.Catalogo -> {
                    CatalogoScreen(
                        viewModel = viewModel,
                        onGoToCart = { pantalla = PantallaActual.Carrito },
                        onProductoAgregado = { nombreProducto ->
                            mostrarMensaje("¡$nombreProducto añadido al carrito! 🍰")
                        }
                    )
                }
                PantallaActual.Carrito -> {
                    CarritoScreen(
                        viewModel = viewModel,
                        onConfirm = { pantalla = PantallaActual.Venta },
                        onCancel = { pantalla = PantallaActual.Catalogo },
                        onBack = { pantalla = PantallaActual.Catalogo }
                    )
                }
                PantallaActual.Venta -> {
                    VentaScreen(
                        viewModel = viewModel,
                        onFinalizarVenta = {
                            mostrarMensaje("¡Gracias por tu compra! 🎉")
                            pantalla = PantallaActual.Catalogo
                        },
                        onBack = { pantalla = PantallaActual.Carrito }
                    )
                }
            }
        }
    }
}

// Mantenemos este componente aquí para llamarlo desde MainActivity
@Composable
fun WelcomeScreen(onEnterClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(CreamWhite).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "Logo",
            tint = ChocolateBrown,
            modifier = Modifier.size(120.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text("¡Bienvenido a\n1000 Sabores!", style = MaterialTheme.typography.headlineLarge, color = ChocolateBrown, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Dulces momentos para ti", style = MaterialTheme.typography.titleMedium, color = ChocolateBrown.copy(alpha = 0.7f))
        Spacer(modifier = Modifier.height(48.dp))
        Button(
            onClick = onEnterClick,
            colors = ButtonDefaults.buttonColors(containerColor = PastelPink),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(0.7f).height(50.dp)
        ) {
            Text("Ver Delicias", fontSize = 18.sp, color = ChocolateBrown, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CatalogoScreen(
    viewModel: MainViewModel,
    onGoToCart: () -> Unit,
    onProductoAgregado: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(CreamWhite)) {
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp)
        ) {
            Text("🍰 Menú de Tortas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = ChocolateBrown, modifier = Modifier.padding(bottom = 16.dp))

            when (uiState) {
                is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = ChocolateBrown) }
                is UiState.Error -> Text("Error al cargar", color = ErrorRed)
                is UiState.Success -> {
                    val productos = (uiState as UiState.Success).productos
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 100.dp)
                    ) {
                        items(productos) { producto ->
                            ProductoItem(producto = producto, onAddClick = {
                                viewModel.agregarAlCarrito(producto)
                                onProductoAgregado(producto.nombre)
                            })
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = onGoToCart,
            containerColor = ChocolateBrown,
            contentColor = CreamWhite,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
        ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = "Ver Carrito")
        }
    }
}

@Composable
fun ProductoItem(producto: Producto, onAddClick: () -> Unit) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 1.2f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale"
    )
    val scope = rememberCoroutineScope()

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = producto.imagen,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(90.dp).clip(RoundedCornerShape(12.dp)),
                placeholder = painterResource(R.drawable.ic_launcher_foreground)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(producto.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ChocolateBrown)
                Surface(color = MintGreen, shape = RoundedCornerShape(6.dp)) {
                    Text(producto.categoria, modifier = Modifier.padding(6.dp, 2.dp), style = MaterialTheme.typography.labelSmall, color = ChocolateBrown)
                }
                Text("$ ${producto.precio.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = ChocolateBrown)
            }
            Button(
                onClick = { isPressed = true; onAddClick(); scope.launch { delay(100); isPressed = false } },
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(45.dp).scale(scale),
                colors = ButtonDefaults.buttonColors(containerColor = PastelPink, contentColor = ChocolateBrown)
            ) {
                Text("+", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(bottom = 2.dp))
            }
        }
    }
}