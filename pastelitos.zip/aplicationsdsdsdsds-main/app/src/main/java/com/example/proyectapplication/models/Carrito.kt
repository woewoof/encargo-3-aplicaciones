package com.example.proyectapplication.models

data class Carrito (
    val producto: Producto,
    val cantidad: Int
)

object Carro {

    val item = mutableListOf<Carrito>()


    fun AgregarProd(producto: Producto) {

        val index = item.indexOfFirst { it.producto.id == producto.id }

        if (index != -1) {

            val productoActual = item[index]

            item[index] = productoActual.copy(cantidad = productoActual.cantidad + 1)
            println("Cantidad aumentada: ${item[index].cantidad} de ${producto.nombre}")
        } else {

            item.add(Carrito(producto, 1))
            println("Producto nuevo agregado: ${producto.nombre}")
        }
    }


    fun CalcularPrecio(): Double {
        return item.sumOf { it.producto.precio * it.cantidad }
    }


    fun Limpiar() {
        item.clear()
        println("Carrito vaciado")
    }
}