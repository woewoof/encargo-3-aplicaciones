package com.example.proyectapplication.models

import com.google.gson.annotations.SerializedName

data class Cliente(
    val id: Long? = null,
    val nombre: String,
    val correo: String,
    val telefono: String
)
