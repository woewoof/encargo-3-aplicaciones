package com.example.proyectapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.proyectapplication.R
import com.example.proyectapplication.models.Carro
import com.example.proyectapplication.ui.viewmodel.MainViewModel
import com.example.proyectapplication.ui.theme.screens.MintGreen
import com.example.proyectapplication.ui.theme.screens.PastelPink
import com.example.proyectapplication.ui.theme.screens.CreamWhite
import com.example.proyectapplication.ui.theme.screens.ChocolateBrown
import com.example.proyectapplication.ui.theme.screens.AccentYellow
import com.example.proyectapplication.ui.theme.screens.ErrorRed


@Composable
fun CarritoScreen(
    viewModel: MainViewModel,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val itemsDelCarro = Carro.item
    val total = Carro.CalcularPrecio()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamWhite)
            .padding(16.dp)
    ) {

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = ChocolateBrown)
            }
            Text(
                text = "Tu Carrito Dulce",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = ChocolateBrown,
                modifier = Modifier.padding(start = 8.dp)
            )
        }


        if (itemsDelCarro.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Gray.copy(alpha = 0.5f), modifier = Modifier.size(80.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Tu carrito está vacío 😢", color = ChocolateBrown.copy(alpha = 0.6f), style = MaterialTheme.typography.titleMedium)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(itemsDelCarro) { itemCarrito ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(4.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = itemCarrito.producto.imagen,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                placeholder = painterResource(R.drawable.ic_launcher_foreground),
                                modifier = Modifier.size(70.dp).clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = itemCarrito.producto.nombre, fontWeight = FontWeight.Bold, color = ChocolateBrown, style = MaterialTheme.typography.titleMedium)
                                Text(text = "$ ${itemCarrito.producto.precio.toInt()} c/u", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Surface(color = MintGreen, shape = RoundedCornerShape(8.dp)) {
                                    Text(text = "x${itemCarrito.cantidad}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = ChocolateBrown)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "$ ${(itemCarrito.producto.precio * itemCarrito.cantidad).toInt()}", fontWeight = FontWeight.Bold, color = ChocolateBrown, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            elevation = CardDefaults.cardElevation(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Total a Pagar:", style = MaterialTheme.typography.titleLarge, color = ChocolateBrown)
                    Text(text = "$ ${total.toInt()}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = ChocolateBrown)
                }
                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (itemsDelCarro.isNotEmpty()) {

                            onConfirm()
                        } else {
                            Toast.makeText(context, "Agrega productos primero", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PastelPink),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "Confirmar Compra", color = ChocolateBrown, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (itemsDelCarro.isNotEmpty()) {
                    OutlinedButton(
                        onClick = {
                            viewModel.vaciarCarrito()
                            Toast.makeText(context, "❌ Venta cancelada", Toast.LENGTH_SHORT).show()
                            onCancel()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed)
                    ) {
                        Text(text = "Cancelar y Vaciar", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}