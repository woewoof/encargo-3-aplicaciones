package com.example.proyectapplication.data.network

import com.example.proyectapplication.models.Cliente
import com.example.proyectapplication.models.Producto
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @GET("productos")
    suspend fun getProductos(): Response<List<Producto>>

    @POST("productos")
    suspend fun guardarProducto(@Body producto: Producto): Response<Producto>

    @POST("clientes")
    suspend fun guardarCliente(@Body cliente: Cliente): Response<Cliente>

    @GET("clientes/{correo}")
    suspend fun obtenerCliente(@Path("correo") correo: String): Response<Cliente>

    @DELETE("clientes/{correo}")
    suspend fun eliminarCliente(@Path("correo") correo: String): Response<Void>
}
