package com.example.proyectapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyectapplication.models.Carro
import com.example.proyectapplication.ui.theme.screens.ChocolateBrown
import com.example.proyectapplication.ui.theme.screens.CreamWhite
import com.example.proyectapplication.ui.theme.screens.MintGreen
import com.example.proyectapplication.ui.viewmodel.MainViewModel

@Composable
fun VentaScreen(
    viewModel: MainViewModel,
    onFinalizarVenta: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val itemsVenta = Carro.item
    val total = Carro.CalcularPrecio()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CreamWhite) 
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        
        Text(
            text = "📃 Resumen de Venta",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = ChocolateBrown,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(4.dp),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {

                Text(
                    text = "Pastelería 1000 Sabores",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ChocolateBrown,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )


                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = ChocolateBrown.copy(alpha = 0.2f))

                if (itemsVenta.isEmpty()) {
                    Text("No hay productos", color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                        items(itemsVenta) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${item.producto.nombre} (x${item.cantidad})",
                                    color = ChocolateBrown,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    "$${(item.producto.precio * item.cantidad).toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = ChocolateBrown
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = ChocolateBrown.copy(alpha = 0.2f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL", fontWeight = FontWeight.Black, color = ChocolateBrown, fontSize = 20.sp)
                    Text("$${total.toInt()}", fontWeight = FontWeight.Black, color = ChocolateBrown, fontSize = 20.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                viewModel.vaciarCarrito()
                onFinalizarVenta()
            },
            colors = ButtonDefaults.buttonColors(containerColor = MintGreen),
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("✅ Finalizar y Pagar", color = ChocolateBrown, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onBack) {
            Text("Volver al Carrito", color = ChocolateBrown)
        }
    }
}