package com.example.proyectapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.proyectapplication.data.network.ApiService
import com.example.proyectapplication.data.repository.AppRepository
import com.example.proyectapplication.ui.screens.ClienteScreen
import com.example.proyectapplication.ui.screens.HomeScreen
import com.example.proyectapplication.ui.screens.WelcomeScreen
import com.example.proyectapplication.ui.viewmodel.AppViewModelFactory
import com.example.proyectapplication.ui.viewmodel.MainViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.example.proyectapplication.ui.theme.screens.MintGreen
import com.example.proyectapplication.ui.theme.screens.PastelPink
import com.example.proyectapplication.ui.theme.screens.CreamWhite
import com.example.proyectapplication.ui.theme.screens.ChocolateBrown
import com.example.proyectapplication.ui.theme.screens.AccentYellow
import com.example.proyectapplication.ui.theme.screens.ErrorRed

class MainActivity : ComponentActivity() {

    private lateinit var repository: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val BASE_URL = "http://192.168.1.14:8080/api/v1/"


        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)

        repository = AppRepository(apiService)

        setContent {
            ProyectApplicationApp(repository = repository)
        }
    }
}

@Composable
fun ProyectApplicationApp(repository: AppRepository) {


    val viewModel: MainViewModel = viewModel(
        factory = AppViewModelFactory(repository)
    )

    val navController = rememberNavController()


    NavHost(
        navController = navController,
        startDestination = "welcome",
        modifier = Modifier.fillMaxSize()
    ) {

        composable("welcome") {
            WelcomeScreen(onEnterClick = {
                navController.navigate("main_flow") {
                    popUpTo("welcome") { inclusive = true }
                }
            })
        }

        composable("main_flow") {
            MainFlowScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun MainFlowScreen(viewModel: MainViewModel) {
    val nestedNavController = rememberNavController()

    Scaffold(
        containerColor = CreamWhite,
        bottomBar = {
            BottomNavigationBar(nestedNavController)
        }
    ) { innerPadding ->

        NavHost(
            navController = nestedNavController,
            startDestination = "home",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(viewModel = viewModel)
            }

            composable("usuario") {
                ClienteScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        containerColor = CreamWhite,
        tonalElevation = 0.dp
    ) {
        NavigationBarItem(
            icon = { Text("🍰") },
            label = { Text("Tienda") },
            selected = currentRoute == "home",
            onClick = {
                navController.navigate("home") {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ChocolateBrown,
                selectedTextColor = ChocolateBrown,
                indicatorColor = MintGreen,
                unselectedIconColor = ChocolateBrown.copy(alpha = 0.5f),
                unselectedTextColor = ChocolateBrown.copy(alpha = 0.5f)
            )
        )

        NavigationBarItem(
            icon = { Text("👤") },
            label = { Text("Usuario") },
            selected = currentRoute == "usuario",
            onClick = {
                navController.navigate("usuario") {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ChocolateBrown,
                selectedTextColor = ChocolateBrown,
                indicatorColor = MintGreen,
                unselectedIconColor = ChocolateBrown.copy(alpha = 0.5f),
                unselectedTextColor = ChocolateBrown.copy(alpha = 0.5f)
            )
        )
    }
}