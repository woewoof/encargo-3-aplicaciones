package com.example.proyectapplication.ui.viewmodel


import com.example.proyectapplication.models.Producto

sealed class UiState {
    object Loading : UiState()
    data class Success(val productos: List<Producto>) : UiState()
    data class Error(val message: String) : UiState()
}
