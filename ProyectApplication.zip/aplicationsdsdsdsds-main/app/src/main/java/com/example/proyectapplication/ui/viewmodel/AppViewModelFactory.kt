package com.example.proyectapplication.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.proyectapplication.data.repository.AppRepository

@JvmSuppressWildcards
class AppViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {

        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(
                repository = repo
            ) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class requested: ${modelClass.name}")
    }
}