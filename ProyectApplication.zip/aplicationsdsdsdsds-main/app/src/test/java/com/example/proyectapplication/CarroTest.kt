package com.example.proyectapplication

import com.example.proyectapplication.models.Carro
import com.example.proyectapplication.models.Producto
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class CarroTest {


    @Before
    fun setup() {
        Carro.Limpiar()
    }

    @Test
    fun `Agregar un producto nuevo aumenta el tamaño de la lista`() {

        val torta = Producto(1, "Torta Test", 1000.0, 0, "Test", 10)


        Carro.AgregarProd(torta)

        assertEquals(1, Carro.item.size)
    }

    @Test
    fun `Agregar el mismo producto dos veces suma cantidad y no duplica item`() {
        val torta = Producto(1, "Torta Chocolate", 5000.0, 0, "Test", 10)


        Carro.AgregarProd(torta)
        Carro.AgregarProd(torta)

        assertEquals(1, Carro.item.size)
        assertEquals(2, Carro.item[0].cantidad)
    }

    @Test
    fun `Calcular precio total funciona correctamente`() {

        val p1 = Producto(1, "Torta 1", 2000.0, 0, "Test", 10)

        val p2 = Producto(2, "Torta 2", 3000.0, 0, "Test", 10)

        Carro.AgregarProd(p1)
        Carro.AgregarProd(p2)

        val totalEsperado = 5000.0
        val totalCalculado = Carro.CalcularPrecio()

        assertEquals(totalEsperado, totalCalculado, 0.0)
    }

    @Test
    fun `Vaciar carrito deja la lista en cero`() {
        val p1 = Producto(1, "Torta 1", 2000.0, 0, "Test", 10)
        Carro.AgregarProd(p1)

        Carro.Limpiar()

        assertEquals(0, Carro.item.size)
    }
}