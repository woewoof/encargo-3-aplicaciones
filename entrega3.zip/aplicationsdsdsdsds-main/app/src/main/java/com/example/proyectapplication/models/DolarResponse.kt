package com.example.proyectapplication.models
import com.google.gson.annotations.SerializedName
data class DolarResponse(
    @SerializedName("valor")
    val valor: Double,
    @SerializedName("fecha")
    val fecha: String
)
