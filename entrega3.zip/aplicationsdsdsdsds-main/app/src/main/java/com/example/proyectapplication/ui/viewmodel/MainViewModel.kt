package com.example.proyectapplication.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyectapplication.data.repository.AppRepository
import com.example.proyectapplication.models.Carro
import com.example.proyectapplication.models.Cliente
import com.example.proyectapplication.models.Producto
import com.example.proyectapplication.Utils.DataProvider // <--- IMPORTANTE: Importa tus datos
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    val uiState: StateFlow<UiState> = _uiState

    private val _clienteActual = MutableStateFlow<Cliente?>(null)
    val clienteActual: StateFlow<Cliente?> = _clienteActual

    private val _mensajeUsuario = MutableStateFlow("")
    val mensajeUsuario: StateFlow<String> = _mensajeUsuario

    init {
        loadProductos()
    }

    // --- CAMBIO AQUÍ: Cargamos tus datos de prueba ---
    fun loadProductos() {
        // Cargamos directamente la lista que creaste en DataProviders.kt
        _uiState.value = UiState.Success(DataProvider.productosPrueba)
    }

    fun buscarCliente(email: String) {
        viewModelScope.launch {
            _mensajeUsuario.value = "Buscando cliente..."
            _clienteActual.value = null

            val result = repository.buscarCliente(email)

            if (result.isSuccess) {
                val cliente = result.getOrNull()
                _clienteActual.value = cliente
                _mensajeUsuario.value = "Cliente '${cliente?.nombre}' encontrado exitosamente."
            } else {
                val e = result.exceptionOrNull()
                _mensajeUsuario.value = "Error: Cliente no encontrado o ${e?.message}"
                _clienteActual.value = null
            }
        }
    }

    fun guardarCliente(nombre: String, email: String, telefono: String) {
        viewModelScope.launch {
            _mensajeUsuario.value = "Guardando cliente..."

            if (email.isBlank() || nombre.isBlank() || telefono.isBlank()) {
                _mensajeUsuario.value = "Error: Todos los campos deben estar llenos."
                return@launch
            }

            val clienteAGuardar = Cliente(
                id = _clienteActual.value?.id,
                nombre = nombre,
                email = email,
                telefono = telefono
            )

            val result = repository.guardarCliente(clienteAGuardar)

            if (result.isSuccess) {
                val clienteGuardado = result.getOrNull()!!
                _clienteActual.value = clienteGuardado
                val accion = if (clienteAGuardar.id == null) "Creado" else "Actualizado"
                _mensajeUsuario.value = "Cliente '${clienteGuardado.nombre}' $accion con éxito."
            } else {
                val e = result.exceptionOrNull()
                _mensajeUsuario.value = "Error al guardar: ${e?.message}"
            }
        }
    }

    fun agregarAlCarrito(producto: Producto) {
        Carro.AgregarProd(producto)
    }
    fun vaciarCarrito() {
        Carro.Limpiar()
    }

    // ... tus otras funciones loadProductos, buscarCliente, guardarCliente ...

    fun eliminarCliente(email: String) {
        viewModelScope.launch {
            _mensajeUsuario.value = "Eliminando cliente..."


            val result = repository.eliminarCliente(email)

            if (result.isSuccess) {
                _mensajeUsuario.value = "🗑️ Cliente eliminado correctamente"
                _clienteActual.value = null // Limpiamos el formulario
            } else {
                val e = result.exceptionOrNull()
                _mensajeUsuario.value = "❌ Error al eliminar: ${e?.message}"
            }
        }
    }
}




