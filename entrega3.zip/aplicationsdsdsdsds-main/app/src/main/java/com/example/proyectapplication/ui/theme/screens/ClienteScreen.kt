package com.example.proyectapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyectapplication.ui.viewmodel.MainViewModel
import com.example.proyectapplication.ui.theme.screens.MintGreen
import com.example.proyectapplication.ui.theme.screens.PastelPink
import com.example.proyectapplication.ui.theme.screens.CreamWhite
import com.example.proyectapplication.ui.theme.screens.ChocolateBrown
import com.example.proyectapplication.ui.theme.screens.AccentYellow
import com.example.proyectapplication.ui.theme.screens.ErrorRed

@Composable
fun ClienteScreen(viewModel: MainViewModel) {


    val clienteActual by viewModel.clienteActual.collectAsState()
    val mensaje by viewModel.mensajeUsuario.collectAsState()

    var email by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }

    LaunchedEffect(clienteActual) {
        clienteActual?.let {
            nombre = it.nombre ?: ""
            email = it.email ?: ""
            telefono = it.telefono ?: ""
        }
    }

    fun limpiarFormulario() {
        email = ""
        nombre = ""
        telefono = ""
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamWhite)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            text = "👤 Gestión de Clientes",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            color = ChocolateBrown,
            modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(6.dp),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "🔍 Buscar Cliente",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = ChocolateBrown,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email del Cliente") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChocolateBrown,
                            unfocusedBorderColor = ChocolateBrown.copy(alpha = 0.5f),
                            focusedLabelColor = ChocolateBrown,
                            cursorColor = ChocolateBrown,
                            focusedTextColor = ChocolateBrown,
                            unfocusedTextColor = ChocolateBrown
                        )
                    )

                    FilledIconButton(
                        onClick = { viewModel.buscarCliente(email) },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = MintGreen),
                        modifier = Modifier.size(56.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Buscar", tint = ChocolateBrown, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(6.dp),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (clienteActual == null) "📝 Nuevo Cliente" else "✏️ Editar Cliente",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = ChocolateBrown
                    )
                    IconButton(onClick = {
                        limpiarFormulario()
                    }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre Completo") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = ChocolateBrown) },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChocolateBrown,
                        unfocusedBorderColor = ChocolateBrown.copy(alpha = 0.5f),
                        focusedLabelColor = ChocolateBrown,
                        cursorColor = ChocolateBrown,
                        focusedTextColor = ChocolateBrown,
                        unfocusedTextColor = ChocolateBrown
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))


                OutlinedTextField(
                    value = telefono,
                    onValueChange = { telefono = it },
                    label = { Text("Teléfono") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = ChocolateBrown) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChocolateBrown,
                        unfocusedBorderColor = ChocolateBrown.copy(alpha = 0.5f),
                        focusedLabelColor = ChocolateBrown,
                        cursorColor = ChocolateBrown,
                        focusedTextColor = ChocolateBrown,
                        unfocusedTextColor = ChocolateBrown
                    )
                )

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = {
                        viewModel.guardarCliente(nombre, email, telefono)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PastelPink),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .shadow(4.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp, pressedElevation = 8.dp)
                ) {
                    Text(
                        text = if (clienteActual == null) "Crear Cliente" else "Guardar Cambios",
                        color = ChocolateBrown,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
            }
        }


        if (clienteActual != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(6.dp),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth(),
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "🗑️ Zona de Peligro",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ErrorRed,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Text(
                        text = "¿Deseas eliminar a este cliente de la base de datos?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Button(
                        onClick = {
                            viewModel.eliminarCliente(email)
                            limpiarFormulario()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed.copy(alpha = 0.1f)),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Eliminar Cliente", color = ErrorRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (mensaje.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = ChocolateBrown),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Text(
                    text = mensaje,
                    color = CreamWhite,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}