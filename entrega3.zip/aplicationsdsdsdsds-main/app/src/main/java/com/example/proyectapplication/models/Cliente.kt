package com.example.proyectapplication.models

import com.google.gson.annotations.SerializedName

data class Cliente(
    @SerializedName("id")
    val id: Long?,

    @SerializedName("nombre")
    val nombre: String,

    @SerializedName("email")
    val email: String,

    @SerializedName("telefono")
    val telefono: String

)