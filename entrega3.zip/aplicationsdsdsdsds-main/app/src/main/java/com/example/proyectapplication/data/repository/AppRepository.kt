package com.example.proyectapplication.data.repository

import com.example.proyectapplication.data.network.ApiService
import com.example.proyectapplication.models.Cliente
import com.example.proyectapplication.models.Producto

class AppRepository(private val apiService: ApiService) {


    suspend fun getProductos(): Result<List<Producto>> {
        return try {
            val response = apiService.getProductos()
            if (response.isSuccessful) {
                Result.success(response.body() ?: emptyList())
            } else {
                Result.failure(Exception("Error en el servidor (${response.code()}): ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Error de red: ${e.message}"))
        }
    }


    suspend fun buscarCliente(email: String): Result<Cliente> {
        return try {
            val response = apiService.buscarCliente(email)

            if (response.isSuccessful) {

                val cliente = response.body()
                if (cliente != null) {
                    Result.success(cliente)
                } else {
                    Result.failure(Exception("Cliente no encontrado (body null)."))
                }
            } else {
                Result.failure(Exception("Error buscando cliente (${response.code()})."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }


    suspend fun guardarCliente(cliente: Cliente): Result<Cliente> {
        return try {
            val response = apiService.guardarCliente(cliente)

            if (response.isSuccessful) {
                Result.success(response.body() ?: throw Exception("Respuesta vacía al guardar."))
            } else {
                Result.failure(Exception("Error al guardar cliente: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }


    suspend fun eliminarCliente(email: String): Result<Boolean> {
        return try {
            val response = apiService.eliminarCliente(email)
            if (response.isSuccessful) {
                Result.success(true)
            } else {
                Result.failure(Exception("Error al eliminar cliente (${response.code()})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}