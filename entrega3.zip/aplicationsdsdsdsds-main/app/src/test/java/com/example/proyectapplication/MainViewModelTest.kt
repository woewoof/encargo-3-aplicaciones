package com.example.proyectapplication

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.proyectapplication.data.repository.AppRepository
import com.example.proyectapplication.models.Cliente
import com.example.proyectapplication.models.Producto
import com.example.proyectapplication.ui.viewmodel.MainViewModel
import com.example.proyectapplication.ui.viewmodel.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.kotlin.any
import org.mockito.kotlin.never
import org.mockito.kotlin.verify
import org.mockito.kotlin.whenever

@ExperimentalCoroutinesApi
class MainViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: MainViewModel

    @Mock
    private lateinit var repository: AppRepository

    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = MainViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // TEST 1: Carga de productos
    @Test
    fun `obtenerProductos actualiza lista cuando es exitoso`() = runTest {
        val listaMock = listOf(Producto(1, "Test Cake", 100.0, 0, "Clásico", 10))

        whenever(repository.getProductos()).thenReturn(Result.success(listaMock))

        viewModel.loadProductos()

        val estadoActual = viewModel.uiState.value

        assertTrue("El estado debería ser Success", estadoActual is UiState.Success)
        assertEquals(listaMock, (estadoActual as UiState.Success).productos)
    }

    // TEST 2: Validación de formulario
    @Test
    fun `guardarCliente con datos invalidos muestra error`() = runTest {
        viewModel.guardarCliente("", "", "")

        assertEquals("Error: Todos los campos deben estar llenos.", viewModel.mensajeUsuario.value)

        verify(repository, never()).guardarCliente(any())
    }

    // TEST 3: Guardar cliente
    @Test
    fun `guardarCliente exitoso actualiza estado cliente`() = runTest {
        val clienteGuardado = Cliente(1, "Juan", "juan@test.com", "978456324")
        val nombre = "Juan"

        whenever(repository.guardarCliente(any())).thenReturn(Result.success(clienteGuardado))

        viewModel.guardarCliente(nombre, clienteGuardado.email ?: "", clienteGuardado.telefono ?: "")

        assertEquals(clienteGuardado, viewModel.clienteActual.value)
        assertTrue(viewModel.mensajeUsuario.value.contains("Juan"))
    }

    // TEST 4: Buscar cliente (NUEVO)
    @Test
    fun `buscarCliente encuentra cliente exitosamente`() = runTest {
        val email = "buscado@test.com"
        val clienteEncontrado = Cliente(2, "Maria", email, "123456789")

        // Simulamos que el repo encuentra al cliente
        whenever(repository.buscarCliente(email)).thenReturn(Result.success(clienteEncontrado))

        viewModel.buscarCliente(email)

        // Verificamos que el clienteActual del ViewModel sea el que encontramos
        assertEquals(clienteEncontrado, viewModel.clienteActual.value)
        assertTrue(viewModel.mensajeUsuario.value.contains("encontrado"))
    }

    // TEST 5: Eliminar cliente (NUEVO)
    @Test
    fun `eliminarCliente exitoso limpia cliente actual`() = runTest {
        val email = "borrar@test.com"

        // Simulamos eliminación exitosa
        whenever(repository.eliminarCliente(email)).thenReturn(Result.success(true))

        viewModel.eliminarCliente(email)

        // Verificamos que se haya limpiado el cliente seleccionado (null)
        assertNull(viewModel.clienteActual.value)
        // Verificamos mensaje de éxito (busca el icono de basura o texto de éxito)
        assertTrue(viewModel.mensajeUsuario.value.contains("eliminado") || viewModel.mensajeUsuario.value.contains("🗑️"))
    }
}